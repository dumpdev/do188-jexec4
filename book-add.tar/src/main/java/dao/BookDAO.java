package dao;

import model.Book;
import java.sql.*;
import java.util.*;

public class BookDAO {
    private String jdbcURL = "jdbc:mysql://db:3306/bookdb";
    private String jdbcUser = "root";
    private String jdbcPass = "pass";
    private Connection getConnection() throws SQLException {

    //Class.forName("com.mysql.cj.jdbc.Driver");
        try {
		        Class.forName("com.mysql.cj.jdbc.Driver");
			    } catch (ClassNotFoundException e) {
				            e.printStackTrace();
					        }
        return DriverManager.getConnection(jdbcURL, jdbcUser, jdbcPass);
    }

    public List<Book> getAllBooks() {
        List<Book> books = new ArrayList<>();
        String sql = "SELECT * FROM books";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Book b = new Book();
                b.setId(rs.getInt("id"));
                b.setTitle(rs.getString("title"));
                b.setAuthor(rs.getString("author"));
                books.add(b);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return books;
    }

    public void addBook(Book book) {
        String sql = "INSERT INTO books (title, author) VALUES (?, ?)";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, book.getTitle());
            stmt.setString(2, book.getAuthor());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
